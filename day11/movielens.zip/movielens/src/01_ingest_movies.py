# Databricks notebook source
from pyspark.sql import functions as F

dbutils.widgets.text("input_path", "/Volumes/workspace/default/movielens/bronze/movies/movies.csv")
dbutils.widgets.text("output_path", "/Volumes/workspace/default/movielens/silver/dev/movies")

input_path = dbutils.widgets.get("input_path").strip()
output_path = dbutils.widgets.get("output_path").strip()
if not input_path or not output_path:
    raise ValueError("input_path and output_path are required")

movies = (
    spark.read.option("header", True).option("mode", "FAILFAST").csv(input_path)
    .select(
        F.col("movieId").cast("long").alias("movie_id"),
        F.trim("title").alias("title"),
        F.trim("genres").alias("genres"),
    )
    .filter(F.col("movie_id").isNotNull() & F.col("title").isNotNull())
    .dropDuplicates(["movie_id"])
)

movies.write.mode("overwrite").parquet(output_path)
print(f"Wrote {movies.count():,} movies to {output_path}")
