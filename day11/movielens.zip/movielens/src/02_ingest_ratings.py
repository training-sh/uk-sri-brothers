# Databricks notebook source
from pyspark.sql import functions as F

dbutils.widgets.text("input_path", "/Volumes/workspace/default/movielens/bronze/ratings/ratings.csv")
dbutils.widgets.text("output_path", "/Volumes/workspace/default/movielens/silver/dev/ratings")

input_path = dbutils.widgets.get("input_path").strip()
output_path = dbutils.widgets.get("output_path").strip()
if not input_path or not output_path:
    raise ValueError("input_path and output_path are required")

ratings = (
    spark.read.option("header", True).option("mode", "FAILFAST").csv(input_path)
    .select(
        F.col("userId").cast("long").alias("user_id"),
        F.col("movieId").cast("long").alias("movie_id"),
        F.col("rating").cast("double").alias("rating"),
        F.to_timestamp(F.from_unixtime(F.col("timestamp").cast("long"))).alias("rated_at"),
    )
    .filter(
        F.col("user_id").isNotNull()
        & F.col("movie_id").isNotNull()
        & F.col("rating").between(0.0, 5.0)
    )
    .dropDuplicates(["user_id", "movie_id", "rated_at"])
)

ratings.write.mode("overwrite").parquet(output_path)
print(f"Wrote {ratings.count():,} ratings to {output_path}")
