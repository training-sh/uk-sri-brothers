# Databricks notebook source
from pyspark.sql import functions as F

dbutils.widgets.text("movies_path", "/Volumes/workspace/default/movielens/silver/dev/movies")
dbutils.widgets.text("ratings_path", "/Volumes/workspace/default/movielens/silver/dev/ratings")
dbutils.widgets.text("output_path", "/Volumes/workspace/default/movielens/silver/dev/popular_movies")
dbutils.widgets.text("minimum_ratings", "100")
dbutils.widgets.text("minimum_average_rating", "4.0")

movies_path = dbutils.widgets.get("movies_path").strip()
ratings_path = dbutils.widgets.get("ratings_path").strip()
output_path = dbutils.widgets.get("output_path").strip()
minimum_ratings = int(dbutils.widgets.get("minimum_ratings"))
minimum_average_rating = float(dbutils.widgets.get("minimum_average_rating"))

movies = spark.read.parquet(movies_path)
ratings = spark.read.parquet(ratings_path)

rating_summary = ratings.groupBy("movie_id").agg(
    F.countDistinct("user_id").alias("rating_user_count"),
    F.round(F.avg("rating"), 3).alias("average_rating"),
)

popular_movies = (
    movies.join(rating_summary, "movie_id", "inner")
    .filter(
        (F.col("rating_user_count") >= minimum_ratings)
        & (F.col("average_rating") >= minimum_average_rating)
    )
    .orderBy(F.desc("average_rating"), F.desc("rating_user_count"), "title")
)

popular_movies.write.mode("overwrite").parquet(output_path)
print(f"Wrote {popular_movies.count():,} popular movies to {output_path}")
display(popular_movies)
