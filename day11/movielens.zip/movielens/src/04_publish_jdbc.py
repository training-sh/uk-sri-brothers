# Databricks notebook source
dbutils.widgets.text("input_path", "/Volumes/workspace/default/movielens/silver/dev/popular_movies")
dbutils.widgets.dropdown("jdbc_enabled", "false", ["false", "true"])
dbutils.widgets.text("jdbc_url", "")
dbutils.widgets.text("jdbc_table", "popular_movies")
dbutils.widgets.text("secret_scope", "movielens")
dbutils.widgets.text("user_secret_key", "jdbc-user")
dbutils.widgets.text("password_secret_key", "jdbc-password")

input_path = dbutils.widgets.get("input_path").strip()
jdbc_enabled = dbutils.widgets.get("jdbc_enabled").strip().lower() == "true"
jdbc_url = dbutils.widgets.get("jdbc_url").strip()
jdbc_table = dbutils.widgets.get("jdbc_table").strip()

popular_movies = spark.read.parquet(input_path)
print(f"Popular movies from {input_path}: {popular_movies.count():,}")
display(popular_movies)

if not jdbc_enabled:
    print("JDBC export is disabled. Set jdbc_enabled=true after configuring the URL and secrets.")
else:
    if not jdbc_url or not jdbc_table:
        raise ValueError("jdbc_url and jdbc_table are required when JDBC export is enabled")

    jdbc_user = dbutils.secrets.get(
        scope=dbutils.widgets.get("secret_scope"),
        key=dbutils.widgets.get("user_secret_key"),
    )
    jdbc_password = dbutils.secrets.get(
        scope=dbutils.widgets.get("secret_scope"),
        key=dbutils.widgets.get("password_secret_key"),
    )

    (
        popular_movies.write.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", jdbc_table)
        .option("user", jdbc_user)
        .option("password", jdbc_password)
        .mode("overwrite")
        .save()
    )
    print(f"Published popular movies to JDBC table {jdbc_table}")
